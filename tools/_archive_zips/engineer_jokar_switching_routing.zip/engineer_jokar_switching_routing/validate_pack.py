#!/usr/bin/env python3
"""Structural validator for the ENGINEER JOKAR switching/routing lesson pack."""
import json, sys
from collections import Counter
from pathlib import Path
P=Path(__file__).with_name('switching_routing_curriculum_pack.json')
def fail(msg):
    print('ERROR:', msg, file=sys.stderr); raise SystemExit(1)
try:
    data=json.loads(P.read_text(encoding='utf-8'))
except Exception as e:
    fail(f'JSON cannot be parsed: {e}')
lessons=data.get('lessons',[]); scope=data.get('scope',[])
if len(lessons)!=470: fail(f'expected 470 lessons, got {len(lessons)}')
topics=sum(len(s.get('topics',[])) for s in scope)
if topics!=94: fail(f'expected 94 topics, got {topics}')
if len(scope)!=18: fail(f'expected 18 subchapters, got {len(scope)}')
expected={7:85,13:145,14:140,20:100}
counts=Counter(x.get('chapter_order') for x in lessons)
if dict(counts)!=expected: fail(f'chapter lesson counts mismatch: {dict(counts)}')
uids=[x.get('uid') for x in lessons]
if None in uids or len(set(uids))!=len(uids): fail('missing or duplicate uid')
positions=[(x.get('chapter_order'),x.get('subchapter_order'),x.get('lesson_order')) for x in lessons]
if len(set(positions))!=len(positions): fail('duplicate chapter/subchapter/lesson position')
for i,x in enumerate(lessons,1):
    if not all(x.get(k) for k in ('title_fa','title_en','summary','full_content','commands','examples','notes','search_query','meta')):
        fail(f'lesson {i} misses a required content field')
    if len(x['full_content'])<2500: fail(f'lesson {i} content too short: {len(x["full_content"])}')
    if x.get('source_status')!='review_required': fail(f'lesson {i} lacks review_required status')
    a=x.get('meta',{}).get('assessment',{})
    qs=a.get('questions',[]); ak=a.get('answer_key',{})
    if len(qs)!=4: fail(f'lesson {i} must have 4 questions')
    qids={q.get('id') for q in qs}
    if qids!={'q1','q2','q3','q4'}: fail(f'lesson {i} question ids mismatch')
    if set(ak)!=qids: fail(f'lesson {i} answer key is not separate/complete')
print('PASS: JSON valid')
print('PASS: 4 existing chapters; counts:', dict(sorted(counts.items())))
print(f'PASS: {topics} topics / {len(lessons)} lessons / {len(scope)} subchapters')
print('PASS: unique UID and positional keys')
print('PASS: required content fields, review flags, four questions and separate keys')

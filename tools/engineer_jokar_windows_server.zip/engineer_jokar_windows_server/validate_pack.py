#!/usr/bin/env python3
"""Structural validator for the ENGINEER JOKAR Windows Server curriculum pack."""
import json, sys
from collections import Counter
from pathlib import Path
P=Path(__file__).with_name('windows_server_complete_curriculum_pack.json')
def fail(msg):
    print('ERROR:',msg,file=sys.stderr); raise SystemExit(1)
try: data=json.loads(P.read_text(encoding='utf-8'))
except Exception as e: fail(f'JSON cannot be parsed: {e}')
lessons=data.get('lessons',[]); scope=data.get('scope',[])
if len(lessons)!=365: fail(f'expected 365 lessons, got {len(lessons)}')
topics=sum(len(s.get('topics',[])) for s in scope)
if topics!=73: fail(f'expected 73 topics, got {topics}')
if len(scope)!=18: fail(f'expected 18 subchapters, got {len(scope)}')
expected={28:40,29:105,30:55,31:50,32:40,35:75}
counts=Counter(x.get('chapter_order') for x in lessons)
if dict(counts)!=expected: fail(f'chapter lesson counts mismatch: {dict(counts)}')
uids=[x.get('uid') for x in lessons]
if None in uids or len(set(uids))!=len(uids): fail('missing or duplicate uid')
positions=[(x.get('chapter_order'),x.get('subchapter_order'),x.get('lesson_order')) for x in lessons]
if len(set(positions))!=len(positions): fail('duplicate chapter/subchapter/lesson position')
for i,x in enumerate(lessons,1):
    if not all(x.get(k) for k in ('title_fa','title_en','summary','full_content','commands','examples','notes','search_query','meta')): fail(f'lesson {i} misses a required content field')
    if len(x['full_content'])<2500: fail(f'lesson {i} content too short: {len(x["full_content"])}')
    if x.get('source_status')!='review_required': fail(f'lesson {i} lacks review_required status')
    a=x.get('meta',{}).get('assessment',{}); qs=a.get('questions',[]); ak=a.get('answer_key',{})
    if len(qs)!=4: fail(f'lesson {i} must have 4 questions')
    qids={q.get('id') for q in qs}
    if qids!={'q1','q2','q3','q4'}: fail(f'lesson {i} question ids mismatch')
    if set(ak)!=qids: fail(f'lesson {i} answer key is not separate/complete')
    for q in qs:
        if 'answer' in q or 'correct_option' in q: fail(f'lesson {i} exposes answer inside questions')
    if x.get('uid') != f'lesson:ch{x["chapter_order"]:02d}:lv{x["subchapter_order"]:03d}:l{x["lesson_order"]:04d}': fail(f'lesson {i} UID/position mismatch')
print('PASS: JSON valid')
print('PASS: existing chapters 28, 29, 30, 31, 32 and 35; counts:',dict(sorted(counts.items())))
print(f'PASS: {topics} topics / {len(lessons)} lessons / {len(scope)} subchapters')
print(f'PASS: minimum full_content length {min(len(x["full_content"]) for x in lessons)} characters')
print('PASS: unique UID/positions, required fields, review flags, four questions and separate answer keys')

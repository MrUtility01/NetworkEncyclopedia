#!/usr/bin/env python3
"""Safe positional updater for existing NetworkEncyclopedia SQLite lesson records.
Default mode is a dry run. It never creates chapters or lessons and never changes UIDs/order/title.
"""
import argparse, json, sqlite3, sys
from datetime import datetime
from pathlib import Path

HERE=Path(__file__).resolve().parent
PACK=HERE/'windows_server_complete_curriculum_pack.json'
FIELDS=('tags','summary','full_content','commands','examples','notes','meta_json','search_query','learning_objectives','source_status','last_updated')
def norm(s):
    return ' '.join(str(s or '').replace('\u200c',' ').split()).strip()
def die(msg):
    print('ERROR:',msg,file=sys.stderr); raise SystemExit(2)
def columns(con,table):
    return {r[1] for r in con.execute(f'PRAGMA table_info({table})')}
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--db',required=True,help='Path to the existing encyclopedia SQLite database')
    ap.add_argument('--pack',default=str(PACK),help='Path to windows_server_complete_curriculum_pack.json')
    ap.add_argument('--apply',action='store_true',help='Commit changes; without this flag, preview only')
    ap.add_argument('--overwrite',action='store_true',help='Allow replacing non-empty existing content after backup')
    args=ap.parse_args()
    db=Path(args.db).expanduser().resolve(); pack_path=Path(args.pack).expanduser().resolve()
    if not db.exists(): die(f'database not found: {db}; no database was created')
    try: data=json.loads(pack_path.read_text(encoding='utf-8'))
    except Exception as e: die(f'cannot read package JSON: {e}')
    lessons=data.get('lessons')
    if not isinstance(lessons,list) or not lessons: die('package has no lessons array')
    try: con=sqlite3.connect(str(db)); con.row_factory=sqlite3.Row
    except Exception as e: die(f'cannot open database: {e}')
    try:
        tables={r['name'] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'chapters','levels','lessons'}<=tables: die('database schema does not include chapters, levels, lessons')
        required={'chapters':{'id','order_index','title_fa'},'levels':{'id','chapter_id','order_index','title_fa'},'lessons':{'id','level_id','order_index','title_fa',*FIELDS}}
        for t,needed in required.items():
            missing=needed-columns(con,t)
            if missing: die(f'table {t} missing columns: {sorted(missing)}')
        staged=[]; errors=[]; existing_content=0
        # Positional lookup deliberately does not create or rename any curriculum records.
        sql='''SELECT c.id AS chapter_id, lv.id AS level_id, l.id AS lesson_id,
                      c.title_fa AS chapter_title, lv.title_fa AS subchapter_title,
                      l.title_fa AS current_title, l.full_content AS current_content
               FROM chapters c JOIN levels lv ON lv.chapter_id=c.id
               JOIN lessons l ON l.level_id=lv.id
               WHERE c.order_index=? AND lv.order_index=? AND l.order_index=?'''
        seen=set()
        for i,x in enumerate(lessons,1):
            pos=(int(x['chapter_order']),int(x['subchapter_order']),int(x['lesson_order']))
            if pos in seen: errors.append(f'{pos}: duplicate position in pack'); continue
            seen.add(pos)
            rows=con.execute(sql,pos).fetchall()
            if len(rows)!=1:
                errors.append(f'{pos}: expected exactly 1 DB row, found {len(rows)}'); continue
            row=rows[0]
            if norm(row['current_title']) != norm(x['title_fa']):
                errors.append(f'{pos}: title mismatch; DB={row["current_title"]!r}; pack={x["title_fa"]!r}'); continue
            if (row['current_content'] or '').strip(): existing_content+=1
            staged.append((row['lesson_id'],x))
        if errors:
            print(f'Preflight failed: {len(errors)} issue(s); nothing changed.')
            for e in errors[:40]: print(' -',e)
            if len(errors)>40: print(f' - ... plus {len(errors)-40} more')
            raise SystemExit(3)
        print(f'PREVIEW OK: {len(staged)} exact positional/title matches in {db}')
        print(f'Existing records with content >0: {existing_content}')
        print('Will update content fields only. Chapter/level/lesson IDs, order, titles, UID, and sync-specific columns are preserved.')
        if not args.apply:
            print('DRY RUN ONLY: no writes performed. Re-run with --apply --overwrite after reviewing this report.')
            return
        if existing_content and not args.overwrite:
            die(f'{existing_content} matching records already contain content; rerun with --overwrite only after making a backup')
        # SQLite's backup API includes committed WAL content and is safer than copying just the .db file.
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        backup=db.with_name(f'{db.stem}.before_windows_server_{stamp}.bak')
        bcon=sqlite3.connect(str(backup))
        try: con.backup(bcon)
        finally: bcon.close()
        now=datetime.now().astimezone().isoformat(timespec='seconds')
        update_sql='''UPDATE lessons SET tags=?, summary=?, full_content=?, commands=?, examples=?, notes=?,
                      meta_json=?, search_query=?, learning_objectives=?, source_status=?, last_updated=? WHERE id=?'''
        try:
            con.execute('BEGIN IMMEDIATE')
            for lesson_id,x in staged:
                values=(x.get('tags',''),x.get('summary',''),x.get('full_content',''),x.get('commands',''),
                        x.get('examples',''),x.get('notes',''),json.dumps(x.get('meta',{}),ensure_ascii=False),
                        x.get('search_query',''),json.dumps(x.get('learning_objectives',[]),ensure_ascii=False),
                        x.get('source_status','review_required'),now,lesson_id)
                con.execute(update_sql,values)
            con.commit()
        except Exception:
            con.rollback(); raise
        # Verify every updated ID now has the expected title and non-empty content.
        for lesson_id,x in staged:
            r=con.execute('SELECT title_fa, full_content, meta_json FROM lessons WHERE id=?',(lesson_id,)).fetchone()
            if not r or norm(r['title_fa'])!=norm(x['title_fa']) or len(r['full_content'] or '')<2500:
                die(f'post-apply verification failed for lesson id {lesson_id}; restore backup {backup}')
            try: json.loads(r['meta_json'] or '{}')
            except Exception: die(f'post-apply meta_json invalid for lesson id {lesson_id}; restore backup {backup}')
        print(f'APPLY PASS: {len(staged)} existing lesson records updated.')
        print(f'Backup: {backup}')
        print('Note: uid/content_hash/device_id/deleted are untouched. If multi-device sync is enabled, publish changes through the app’s supported sync workflow and verify hashes/sync status.')
    finally:
        con.close()
if __name__=='__main__': main()

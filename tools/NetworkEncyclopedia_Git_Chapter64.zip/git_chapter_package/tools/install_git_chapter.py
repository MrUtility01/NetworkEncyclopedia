#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""نصب افزایشی فصل Git در NetworkEncyclopedia، بدون reseed مخرب."""
from __future__ import annotations
import argparse
import hashlib
import shutil
import sqlite3
import sys
from datetime import datetime
from pathlib import Path

MARKER_CURRICULUM = "# BEGIN GENERATED GIT CHAPTER 64"
MARKER_ROUTER = "# BEGIN GENERATED GIT TEACHER ROUTE"


def write_backup(path: Path) -> Path:
    backup = path.with_name(f"{path.stem}.pre_git_chapter_{datetime.now().strftime('%Y%m%d_%H%M%S')}{path.suffix}")
    src = sqlite3.connect(str(path))
    dst = sqlite3.connect(str(backup))
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return backup


def replace_once(path: Path, old: str, new: str, description: str) -> bool:
    data = path.read_text(encoding="utf-8")
    if new in data:
        print(f"[OK] {description}: already patched")
        return False
    if old not in data:
        raise RuntimeError(f"الگوی لازم برای {description} پیدا نشد: {path}. نسخه مخزن ممکن است متفاوت باشد؛ فایل را دستی ادغام کنید.")
    path.write_text(data.replace(old, new, 1), encoding="utf-8", newline="\n")
    print(f"[PATCH] {description}")
    return True


def patch_curriculum(repo: Path) -> None:
    path = repo / "server" / "core" / "full_curriculum.py"
    data = path.read_text(encoding="utf-8")
    if MARKER_CURRICULUM not in data:
        import_anchor = "import re\n"
        import_line = "from core.chapter_git_teacher import get_git_chapter_levels  # Git chapter 64\n"
        if import_line not in data:
            if import_anchor not in data:
                raise RuntimeError(f"محل import در {path} پیدا نشد")
            data = data.replace(import_anchor, import_anchor + import_line, 1)
        anchor = "    return C\n"
        pos = data.rfind(anchor)
        if pos < 0:
            raise RuntimeError(f"return C در {path} پیدا نشد")
        block = (
            f"    {MARKER_CURRICULUM}\n"
            "    C.append((64, 'فصل ۶۴: Git و GitHub از صفر تا مهندسی حرفه‌ای', 'Ch64 Git and GitHub', get_git_chapter_levels()))\n"
            "    # END GENERATED GIT CHAPTER 64\n\n"
        )
        data = data[:pos] + block + data[pos:]
        path.write_text(data, encoding="utf-8", newline="\n")
        print("[PATCH] فصل ۶۴ به full_curriculum.py اضافه شد")
    else:
        print("[OK] full_curriculum.py: already patched")


def patch_rich_router(repo: Path) -> None:
    path = repo / "server" / "core" / "rich_content.py"
    data = path.read_text(encoding="utf-8")
    if MARKER_ROUTER in data:
        print("[OK] rich_content.py: already patched")
        return
    anchor = "    try:\n        from core.chapter17_teacher import build_chapter17_lesson"
    route = (
        f"    {MARKER_ROUTER}\n"
        "    try:\n"
        "        from core.chapter_git_teacher import build_git_lesson, is_git_title\n"
        "        if is_git_title(title_fa):\n"
        "            c = build_git_lesson(title_fa, title_en)\n"
        "            if c:\n"
        "                return c\n"
        "    except Exception:\n"
        "        pass\n"
        "    # END GENERATED GIT TEACHER ROUTE\n"
    )
    if anchor not in data:
        raise RuntimeError(f"محل اتصال teacher در {path} پیدا نشد؛ نسخه فایل با نسخه بررسی‌شده تفاوت دارد.")
    data = data.replace(anchor, route + anchor, 1)
    path.write_text(data, encoding="utf-8", newline="\n")
    print("[PATCH] مسیریابی درس‌های Git در rich_content.py انجام شد")


def patch_labels(repo: Path) -> None:
    replacements = [
        (repo / "README.md", "۶۳ فصل", "۶۴ فصل"),
        (repo / "README_FA.txt", "۶۳ فصل", "۶۴ فصل"),
        (repo / "server" / "templates" / "index.html", "فهرست ۶۳ فصل", "فهرست ۶۴ فصل"),
        (repo / "server" / "app.py", "seed 63 chapters...", "seed 64 chapters..."),
        (repo / "server" / "core" / "db.py", "SQLite سبک برای نسخه وب — ۶۳ فصل", "SQLite سبک برای نسخه وب — ۶۴ فصل"),
        (repo / "server" / "core" / "full_curriculum.py", "v1.0 Dense — ۶۰ فصل", "v1.1 Dense — ۶۴ فصل"),
    ]
    for path, old, new in replacements:
        if not path.exists():
            continue
        data = path.read_text(encoding="utf-8")
        if new in data:
            continue
        if old in data:
            path.write_text(data.replace(old, new), encoding="utf-8", newline="\n")
            print(f"[PATCH] شمارنده/توضیح: {path.relative_to(repo)}")


def migrate_existing_db(repo: Path) -> None:
    db_path = repo / "server" / "data" / "encyclopedia.db"
    if not db_path.exists():
        print("[INFO] دیتابیس موجود پیدا نشد؛ در اولین اجرای سرور، seed کامل ۶۴ فصل ساخته می‌شود.")
        return

    # مسیر import را فقط برای همین فرایند نصب می‌افزاییم.
    server_dir = repo / "server"
    if str(server_dir) not in sys.path:
        sys.path.insert(0, str(server_dir))
    from core.db import WebDB
    from core.seed_helpers import insert_rich_lesson
    from core.full_curriculum import get_full_curriculum

    db = WebDB(str(db_path))
    try:
        row = db.conn.execute("SELECT COUNT(*) AS n FROM chapters").fetchone()
        count = int(row["n"])
        exists = db.conn.execute("SELECT id FROM chapters WHERE order_index=64 OR title_fa LIKE '%Git و GitHub از صفر تا مهندسی حرفه‌ای%'").fetchone()
        if exists:
            print("[OK] دیتابیس از قبل فصل ۶۴ را دارد؛ migration تکرار نشد.")
            return
        if count < 60:
            print("[INFO] دیتابیس هنوز seed کامل ندارد؛ migration جداگانه لازم نیست و سرور تمام ۶۴ فصل را seed می‌کند.")
            return
        occupied = db.conn.execute("SELECT title_fa FROM chapters WHERE order_index=64").fetchone()
        if occupied:
            raise RuntimeError(f"شماره فصل ۶۴ قبلاً اشغال شده است: {occupied['title_fa']}")

        backup = write_backup(db_path)
        chapter = next((x for x in get_full_curriculum() if x[0] == 64), None)
        if not chapter:
            raise RuntimeError("تعریف فصل ۶۴ در get_full_curriculum پیدا نشد.")
        _, title_fa, title_en, levels = chapter
        cur = db.conn.cursor()
        try:
            cur.execute("BEGIN IMMEDIATE")
            cur.execute(
                "INSERT INTO chapters(order_index,title_fa,title_en,description) VALUES (?,?,?,?)",
                (64, title_fa, title_en, "آموزش جامع Git و GitHub از L0 تا L4، همراه با Lab و سناریوی سازمانی."),
            )
            ch_id = cur.lastrowid
            now = datetime.now().isoformat(timespec="seconds")
            n_lessons = 0
            for lv_order, (lv_title, lessons) in enumerate(levels, 1):
                cur.execute(
                    "INSERT INTO levels(chapter_id,order_index,title_fa,title_en) VALUES (?,?,?,?)",
                    (ch_id, lv_order, lv_title, ""),
                )
                lv_id = cur.lastrowid
                for lesson_order, (fa, en) in enumerate(lessons, 1):
                    insert_rich_lesson(cur, lv_id, lesson_order, fa, en, now)
                    n_lessons += 1
            db.conn.commit()
        except Exception:
            db.conn.rollback()
            raise
        db.ensure_sync_columns()
        print(f"[MIGRATED] فصل ۶۴ در دیتابیس اضافه شد: {len(levels)} زیرشاخه، {n_lessons} درس")
        print(f"[BACKUP] نسخه پشتیبان دیتابیس: {backup}")
    finally:
        db.conn.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="نصب افزایشی فصل Git و GitHub برای NetworkEncyclopedia")
    parser.add_argument("--repo", required=True, help="مسیر ریشه مخزن NetworkEncyclopedia که server/ داخل آن است")
    parser.add_argument("--skip-db", action="store_true", help="فقط فایل‌های کد را patch کن و دیتابیس را تغییر نده")
    args = parser.parse_args()
    repo = Path(args.repo).expanduser().resolve()
    required = [repo / "server" / "core" / "full_curriculum.py", repo / "server" / "core" / "rich_content.py"]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        print("خطا: مسیر --repo باید ریشه NetworkEncyclopedia باشد. فایل‌های پیدا نشده:")
        print("\n".join(missing))
        return 2

    source_teacher = Path(__file__).resolve().parents[1] / "server" / "core" / "chapter_git_teacher.py"
    target_teacher = repo / "server" / "core" / "chapter_git_teacher.py"
    if target_teacher.exists():
        current_hash = hashlib.sha256(target_teacher.read_bytes()).hexdigest()
        package_hash = hashlib.sha256(source_teacher.read_bytes()).hexdigest()
        if current_hash == package_hash:
            print("[OK] chapter_git_teacher.py دقیقاً با نسخه بسته یکسان است.")
        else:
            backup_code = target_teacher.with_name(f"chapter_git_teacher.pre_git_chapter_{datetime.now().strftime('%Y%m%d_%H%M%S')}.py.bak")
            shutil.copy2(target_teacher, backup_code)
            print(f"[BACKUP] فایل قبلی teacher: {backup_code}")
            shutil.copy2(source_teacher, target_teacher)
    else:
        shutil.copy2(source_teacher, target_teacher)
    
    print(f"[COPY] {target_teacher}")

    patch_curriculum(repo)
    patch_rich_router(repo)
    patch_labels(repo)
    if not args.skip_db:
        migrate_existing_db(repo)
    print("\nنصب فایل‌های فصل Git تمام شد. سرور را restart و API /api/chapters و /api/stats را بررسی کنید.")
    print("نکته: endpoint بازسازی کامل دیتابیس را برای نصب این فصل اجرا نکنید؛ ممکن است تغییرات محلی محتوا پاک شوند.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"نصب کامل نشد: {exc}")
        raise SystemExit(1)

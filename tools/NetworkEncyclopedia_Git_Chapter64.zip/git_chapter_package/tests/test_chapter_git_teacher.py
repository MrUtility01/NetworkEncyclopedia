# -*- coding: utf-8 -*-
"""آزمون‌های smoke برای موتور محتوای فصل Git."""
from __future__ import annotations
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "server" / "core" / "chapter_git_teacher.py"
SPEC = importlib.util.spec_from_file_location("chapter_git_teacher", MODULE)
assert SPEC and SPEC.loader
teacher = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(teacher)


def test_chapter_shape() -> None:
    summary = teacher.chapter_summary()
    assert summary == {"sections": 8, "topics": 60, "levels_per_topic": 5, "lessons": 300}
    levels = teacher.get_git_chapter_levels()
    assert len(levels) == 8
    assert sum(len(lessons) for _, lessons in levels) == 300


def test_every_lesson_has_detailed_content_and_routes() -> None:
    for _, lessons in teacher.get_git_chapter_levels():
        for title_fa, title_en in lessons:
            assert teacher.is_git_title(title_fa), title_fa
            lesson = teacher.build_git_lesson(title_fa, title_en)
            assert lesson is not None
            assert lesson["level"] in {"L0", "L1", "L2", "L3", "L4"}
            assert len(lesson["full_content"]) >= 2000, (title_fa, len(lesson["full_content"]))
            assert lesson["commands"] and lesson["examples"] and lesson["lab"]
            assert lesson["learning_objectives"]


def test_legacy_git_workflow_routes() -> None:
    assert teacher.is_git_title("[L2] Git Workflow — Admin")
    lesson = teacher.build_git_lesson("[L2] Git Workflow — Admin")
    assert lesson and lesson["level"] == "L2"


if __name__ == "__main__":
    test_chapter_shape()
    test_every_lesson_has_detailed_content_and_routes()
    test_legacy_git_workflow_routes()
    print("PASS: 60 موضوع، 8 زیرشاخه و 300 درس بررسی شدند.")

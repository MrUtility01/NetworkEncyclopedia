@echo off
chcp 65001 >nul
cd /d "%~dp0..\server"
python -m pip install -r requirements.txt
python app.py
pause
